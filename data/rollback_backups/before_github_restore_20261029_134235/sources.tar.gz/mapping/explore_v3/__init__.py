"""Frozen v3 exploration algorithms; shared unchanged helpers resolve in mapping.

Copied algorithms are byte-for-byte from commit 599499a; adapters.py contains
the explicit compatibility boundary for the current navigation application.
"""
from pathlib import Path

__path__.append(str(Path(__file__).resolve().parent.parent))
