# 探索专用的 v3 占据建图与车辆关联适配

来源为 Git 提交 `599499a`（v3）。`source_manifest.json` 记录七个原始模块的 SHA-256；
这些文件保持原始内容，接口适配集中在 `adapters.py`。
未变化的射线、机身覆盖、回环重建等辅助模块通过包搜索路径复用。

仅 `DemoRuntime(exploration=True)` 选用本后端：

- v3 局部/全局占据地图，原有 LiDAR→PX4 NED 融合与顺序地图更新；
- 当前车辆跨视角关联、稳定表面并集、多车面中心估计及碎片补充观察接口；
- v3 非车辆地标关联和几何过滤；
- v3 在线导航地图的回环重建；实时与回环语义回放共用 adapters.SemanticInstanceMapper。

SAM3 的服务、模型、请求格式和掩膜生成不变。当前掩膜反投影/雷达匹配的核心计算
与 v3 一致，定位差异来自后续实例关联和表面拟合；当前处理器注入适配后的 mapper。
YOLO-World+SAM2 也可通过原有入口使用该 mapper。

接口适配只提供当前执行器需要的 execution_snapshot、前向净空和地图心跳接口；
v3 每次融合完成后发布快照，避免控制线程反复构建完整地图。
车辆关联与几何恢复集中在 adapters.SemanticInstanceMapper：继承旧地标处理，
替换车辆tracker，补充几何发布字段，并复用当前车辆补充观察候选接口。
七个冻结源文件不修改，车辆tracker直接复用 mapping.vehicle_instance_tracker，
不复制另一份实现，不扩大关联距离门槛。

explore 不启动后来引入的 FAST-LIO 支线；配置中的 fastlio 选择继续用于独立目标导航。
`navigate_target.py`、独立地图加载、多目标输入、目标验证、飞行控制和 SAM3 服务文件
均未回退。探索 Utility 决策、A*/EGO 执行也未回退。
最终地图的连续编号与展示功能保留。

运行方式仍为 `python run_explore.py`，识别后端沿用 `config/explore.json`，不需要 CMake。
入口会打印“探索建图：2026-10-20 v3 / PX4 + LiDAR；车辆使用跨视角关联与多车面融合”。

回退前的共享模块备份位于 `data/rollback_backups/before_explore_v3_20261029/`。
2026-10-29 恢复车辆逻辑后，已有地图不会重写；下次探索生效。
回放核对：tools/audit_vehicle_rollback.py；详细证据在
data/audits/vehicle_rollback_20261029/restored.json。
