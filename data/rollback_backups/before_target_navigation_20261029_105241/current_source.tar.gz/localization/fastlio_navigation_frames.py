"""Time-bounded transforms between the LIO map and the PX4 control frame.

This module performs coordinate conversions only. It does not issue commands
or substitute PX4 poses for missing LIO tracking samples.
"""
from collections import deque
from dataclasses import dataclass
import threading
import time

import numpy as np
from scipy.spatial.transform import Rotation, Slerp


@dataclass(frozen=True)
class FrameSample:
    timestamp: float
    received_monotonic: float
    map_from_body: np.ndarray
    px4_from_body: np.ndarray


def _rigid(value):
    pose = np.asarray(value, dtype=float)
    if (pose.shape != (4, 4) or not np.isfinite(pose).all()
            or not np.allclose(pose[3], [0., 0., 0., 1.], atol=1e-7)
            or not np.allclose(pose[:3, :3].T @ pose[:3, :3], np.eye(3), atol=1e-5)
            or not np.isclose(np.linalg.det(pose[:3, :3]), 1., atol=1e-5)):
        raise ValueError('Expected a finite rigid SE(3) pose')
    result = pose.copy()
    result.setflags(write=False)
    return result


def _interpolate(a, b, fraction):
    result = np.eye(4)
    result[:3, :3] = Slerp([0., 1.], Rotation.from_matrix(
        np.stack([a[:3, :3], b[:3, :3]])))(fraction).as_matrix()
    result[:3, 3] = a[:3, 3] * (1. - fraction) + b[:3, 3] * fraction
    return result


class FastLioNavigationFrames:
    """Pair LIO and PX4 poses; use matched LIO poses as map coordinates.

    T_map_from_px4 is updated from paired same-time body poses. It is used
    only to express map goals in the PX4 control frame, and to associate
    already synchronized observations with the LIO map frame.
    """
    def __init__(self, *, max_age=1., max_interpolation_gap=.5, capacity=512,
                 clock=time.monotonic, wall_clock=time.time):
        if max_age <= 0 or max_interpolation_gap <= 0 or capacity < 2:
            raise ValueError('Invalid FAST-LIO frame limits')
        self.max_age = float(max_age)
        self.max_interpolation_gap = float(max_interpolation_gap)
        self.clock = clock
        self.wall_clock = wall_clock
        self._samples = deque(maxlen=capacity)
        self._error = None
        self._lock = threading.Lock()

    def add(self, timestamp, map_from_body, px4_from_body):
        stamp = float(timestamp)
        if not np.isfinite(stamp):
            raise ValueError('Invalid FAST-LIO shared timestamp')
        sample = FrameSample(stamp, float(self.clock()), _rigid(map_from_body),
                             _rigid(px4_from_body))
        with self._lock:
            if self._error is not None:
                raise RuntimeError('FAST-LIO frame source failed') from self._error
            if self._samples and stamp <= self._samples[-1].timestamp:
                raise ValueError('FAST-LIO shared timestamps must increase')
            self._samples.append(sample)

    def fail(self, error):
        with self._lock:
            self._error = error if isinstance(error, Exception) else RuntimeError(str(error))

    def latest(self):
        with self._lock:
            error = self._error
            sample = self._samples[-1] if self._samples else None
        if error is not None:
            raise RuntimeError('FAST-LIO frame source failed') from error
        if sample is None:
            raise RuntimeError('FAST-LIO frame source is not ready')
        age = float(self.clock()) - sample.received_monotonic
        if age < 0 or age > self.max_age:
            raise RuntimeError(f'FAST-LIO frame source is stale: {age:.3f}s')
        # Tracking results can be computed late from queued scans. Their
        # publication time alone must not make an old source frame look fresh.
        source_age = float(self.wall_clock()) - sample.timestamp
        if source_age < -.05 or source_age > self.max_age:
            raise RuntimeError(f'FAST-LIO source timestamp is stale: {source_age:.3f}s')
        return sample

    def at(self, timestamp):
        """Interpolate paired poses for a sensor timestamp; never extrapolate."""
        stamp = float(timestamp)
        if not np.isfinite(stamp):
            raise ValueError('Invalid sensor timestamp')
        with self._lock:
            error, samples = self._error, tuple(self._samples)
        if error is not None:
            raise RuntimeError('FAST-LIO frame source failed') from error
        stamps = np.asarray([sample.timestamp for sample in samples])
        i = int(np.searchsorted(stamps, stamp))
        if i < len(samples) and samples[i].timestamp == stamp:
            return samples[i]
        if i == 0 or i == len(samples):
            raise ValueError('Sensor timestamp outside LIO pose history')
        before, after = samples[i - 1], samples[i]
        gap = after.timestamp - before.timestamp
        if gap > self.max_interpolation_gap:
            raise ValueError('LIO pose history gap exceeds limit')
        fraction = (stamp - before.timestamp) / gap
        return FrameSample(stamp, after.received_monotonic,
                           _rigid(_interpolate(before.map_from_body, after.map_from_body, fraction)),
                           _rigid(_interpolate(before.px4_from_body, after.px4_from_body, fraction)))

    @staticmethod
    def map_from_px4(sample):
        return sample.map_from_body @ np.linalg.inv(sample.px4_from_body)

    def px4_goal(self, map_point):
        point = np.asarray(map_point, dtype=float)
        if point.shape != (3,) or not np.isfinite(point).all():
            raise ValueError('Invalid map waypoint')
        px4_from_map = np.linalg.inv(self.map_from_px4(self.latest()))
        return px4_from_map[:3, :3] @ point + px4_from_map[:3, 3]

    def px4_position_command(self, map_point, map_yaw):
        """Convert position and heading with one consistent frame sample."""
        point = np.asarray(map_point, dtype=float)
        yaw = float(map_yaw)
        if point.shape != (3,) or not np.isfinite(point).all() or not np.isfinite(yaw):
            raise ValueError('Invalid map position command')
        px4_from_map = np.linalg.inv(self.map_from_px4(self.latest()))
        rotation = px4_from_map[:3, :3]
        heading = rotation @ np.array([np.cos(yaw), np.sin(yaw), 0.])
        if np.linalg.norm(heading[:2]) < 1e-6:
            raise ValueError('Map heading is vertical in the control frame')
        return (rotation @ point + px4_from_map[:3, 3],
                float(np.arctan2(heading[1], heading[0])))

    def px4_velocity(self, map_velocity):
        velocity = np.asarray(map_velocity, dtype=float)
        if velocity.shape != (3,) or not np.isfinite(velocity).all():
            raise ValueError('Invalid map velocity command')
        px4_from_map = np.linalg.inv(self.map_from_px4(self.latest()))
        return px4_from_map[:3, :3] @ velocity

    def map_observation_pose(self, timestamp, px4_from_sensor):
        """Transform a synchronized camera pose into the LIO map frame."""
        sample = self.at(timestamp)
        return self.map_from_px4(sample) @ _rigid(px4_from_sensor)
