"""LIO point and probabilistic occupancy mapping, separate from flight control.

The first tracking pose is aligned once to simultaneous PX4 NED. Subsequent
poses retain LIO drift; repeatedly anchoring to PX4 would hide that drift.
"""
import json
from html import escape
import time
import threading
from dataclasses import replace
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation


class FastLioLiveMap:
    def __init__(self, directory, scan_model):
        if scan_model not in {'snapshot', 'snapshot_assumed'}:
            raise ValueError('FAST-LIO occupancy requires an explicit instantaneous scan model')
        self.directory = Path(directory)
        self.scan_model = scan_model
        self.alignment = None
        self.cells = set()
        self.path = []
        self.last_publish = 0.
        self.resolution = .15
        self.timestamp = None
        from config.global_map_config import GlobalSparseMapConfig
        from config.lidar_config import LidarConfig
        from mapping.global_sparse_occupancy_map import GlobalSparseOccupancyMap
        self.occupancy = GlobalSparseOccupancyMap(replace(
            GlobalSparseMapConfig(), enabled=True, resolution=self.resolution,
            ray_step=self.resolution / 2, max_depth=LidarConfig().max_range,
            loop_closure_enabled=False, visualize=False, output_dir=self.directory,
        ))
        self._condition = threading.Condition()
        self._pending = None
        self._busy = False
        self._closed = False
        self._thread = None
        self.error = None
        self.estimator_error = None
        self.counts = dict(tracking_frames=0, integrated_scans=0, skipped_mapping_scans=0,
                           rejected_tracking_frames=0)
        from localization.fastlio_navigation_frames import FastLioNavigationFrames
        self.navigation_frames = FastLioNavigationFrames()
        from localization.fastlio_semantics import FastLioSemantics
        self.semantics = FastLioSemantics()

    def update(self, result, px4_pose, shared_timestamp=None, points_body=None):
        self.raise_if_failed()
        if self._closed:
            raise RuntimeError('FAST-LIO map is closed')
        if result.get('status') != 'tracking':
            self.counts['rejected_tracking_frames'] += 1
            return False
        pose = np.asarray(result['pose'], dtype=float)
        points = np.asarray(result['points_world'], dtype=float)
        px4 = np.asarray(px4_pose, dtype=float)
        if (pose.shape != (4, 4) or points.ndim != 2 or points.shape[1] != 3
                or px4.shape != (7,) or not all(np.isfinite(x).all() for x in (pose, points, px4))):
            raise ValueError('Invalid FAST-LIO map pose/points')
        stamp = float(result['timestamp'])
        if not np.isfinite(stamp) or (self.timestamp is not None and stamp <= self.timestamp):
            raise ValueError('FAST-LIO map timestamps must increase')
        if points_body is not None:
            body = np.asarray(points_body, dtype=float)
            if body.ndim != 2 or body.shape[1] != 3 or not np.isfinite(body).all():
                raise ValueError('Invalid FAST-LIO body scan')
            # Type20 uses a zero mount transform and instantaneous scan model.
            # Use actual returns, not estimator voxel centroids, for ray evidence.
            points = body @ pose[:3, :3].T + pose[:3, 3]
        if self.alignment is None:
            anchor = np.eye(4)
            anchor[:3, :3] = Rotation.from_quat(px4[[4, 5, 6, 3]]).as_matrix()
            anchor[:3, 3] = px4[:3]
            self.alignment = anchor @ np.linalg.inv(pose)
        mapped = points @ self.alignment[:3, :3].T + self.alignment[:3, 3]
        current = self.alignment @ pose
        if shared_timestamp is not None:
            px4_transform = np.eye(4)
            px4_transform[:3, :3] = Rotation.from_quat(px4[[4, 5, 6, 3]]).as_matrix()
            px4_transform[:3, 3] = px4[:3]
            self.navigation_frames.add(float(shared_timestamp), current, px4_transform)
            self.semantics.add_pose(float(shared_timestamp), current @ np.linalg.inv(px4_transform))
        self.path.append(current[:3, 3].tolist())
        self.timestamp = stamp
        self.counts['tracking_frames'] += 1
        with self._condition:
            if self._pending is not None:
                self.counts['skipped_mapping_scans'] += 1
            self._pending = (current[:3, 3].copy(), mapped, stamp)
            if self._thread is None:
                self._thread = threading.Thread(target=self._map_loop, name='FastLioOccupancy', daemon=True)
                self._thread.start()
            self._condition.notify_all()
        return True

    def set_estimator_error(self, message):
        """Make a stopped estimator visible even while PX4 navigation continues."""
        self.estimator_error = str(message)
        self.navigation_frames.fail(message)
        self._write_status()

    def _write_status(self):
        self.directory.mkdir(parents=True, exist_ok=True)
        from navigation.scene_memory import write_json
        write_json(self.directory / 'map_status.json', dict(
            status='failed' if self.error or self.estimator_error else
                   'closed' if self._closed else 'tracking',
            error=str(self.error) if self.error else self.estimator_error,
            last_source_timestamp=self.timestamp, counts=dict(self.counts),
            last_occupancy_timestamp=self.occupancy.last_update_timestamp,
            scan_model=self.scan_model, controls_navigation=False))

    def raise_if_failed(self):
        if self.error is not None:
            raise RuntimeError('FAST-LIO occupancy mapping failed') from self.error

    def _map_loop(self):
        try:
            while True:
                with self._condition:
                    while self._pending is None and not self._closed:
                        self._condition.wait()
                    if self._pending is None:
                        return
                    origin, points, stamp = self._pending
                    self._pending = None
                    self._busy = True
                self.occupancy.integrate_lidar_points(origin, points, stamp, origin)
                cells = np.unique(np.floor(points / self.resolution).astype(np.int64), axis=0)
                self.cells.update(map(tuple, cells.tolist()))
                self.counts['integrated_scans'] += 1
                if time.monotonic() - self.last_publish >= 2.:
                    self.publish()
                with self._condition:
                    self._busy = False
                    self._condition.notify_all()
        except Exception as error:
            with self._condition:
                self.error = error
                self._busy = False
                self._condition.notify_all()
            self._write_status()

    def wait_idle(self, timeout=30.):
        """Drain mapping for deterministic offline replay without dropping scans."""
        deadline = time.monotonic() + timeout
        with self._condition:
            while self._pending is not None or self._busy:
                self.raise_if_failed()
                remaining = deadline-time.monotonic()
                if remaining <= 0:
                    raise TimeoutError('FAST-LIO occupancy mapping did not finish')
                self._condition.wait(remaining)
        self.raise_if_failed()

    def publish(self):
        if not self.path:
            return
        self.directory.mkdir(parents=True, exist_ok=True)
        cells = np.asarray(sorted(self.cells), dtype=np.int64).reshape(-1, 3)
        path = np.asarray(self.path.copy())
        # This is an XY projection of returns at ALL heights, not a free-space grid.
        xy = np.unique(cells[:, :2], axis=0) * self.resolution
        extent = np.vstack((xy, path[:, :2]))
        low = extent.min(axis=0) - 1
        span = np.maximum(extent.max(axis=0) - low + 1, 2)
        rects = ''.join(f'<rect x="{x:.2f}" y="{y:.2f}" width=".15" height=".15"/>' for x, y in xy)
        line = ' '.join(f'{x:.3f},{y:.3f}' for x, y in path[:, :2])
        labels = ''
        for obj in self.semantics.records:
            center = obj.get('position', obj.get('position_world'))
            if center is None:
                continue
            identity = escape(str(obj['instance_id']))
            labels += (f'<circle cx="{center[0]}" cy="{center[1]}" r=".18" fill="#0077ff"/>'
                       f'<text x="{center[0]}" y="{center[1]}" font-size=".35" fill="#0050bb">{identity}</text>')
        from navigation.scene_memory import write_json
        write_json(self.directory / 'semantic_map.json', dict(
            frame='lio_aligned_to_initial_px4_ned', controls_navigation=False,
            identity_scope='independent_lio_instances', objects=self.semantics.records,
            synchronization=dict(self.semantics.counts)))
        write_json(self.directory / 'scene_graph.json',
                   self.semantics.scene_graph.snapshot(self.semantics.records, self.directory.parent.name))
        html = (f'<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="3">'
                f'<title>FAST-LIO experimental map</title><p>FAST-LIO 实时点云地图（非导航占据地图）'
                f'；扫描模型：{self.scan_model}；时间：{self.timestamp:.3f}；帧数：{len(path)}。'
                '<a href="occupancy.html">查看三维占据地图高度切片</a>。'
                '全部高度的回波投影；灰色不代表当前飞行高度不可通行。蓝色标签为 LIO 独立语义实例（不与旧地图 ID 通用）。PX4 继续控制飞行。<a href="scene_graph.json">物体与观测图 JSON</a></p>'
                f'<svg width="95vw" height="85vh" viewBox="{low[0]} {low[1]} {span[0]} {span[1]}">'
                f'<g fill="#78858b">{rects}</g><polyline points="{line}" fill="none" stroke="#1677ff" '
                f'stroke-width=".07"/><circle cx="{path[-1,0]}" cy="{path[-1,1]}" r=".2" fill="red"/>{labels}</svg>')
        temporary = self.directory / 'map.html.tmp'
        temporary.write_text(html, encoding='utf-8')
        temporary.replace(self.directory / 'map.html')
        self._publish_occupancy()
        self._write_status()
        self.last_publish = time.monotonic()

    def _publish_occupancy(self):
        snapshot = self.occupancy.snapshot()
        occupied = snapshot.occupied_points_ned
        free = snapshot.free_points_ned
        # Browser preview only; saved occupancy and PLY retain every voxel.
        occupied = occupied[::max(1, int(np.ceil(len(occupied)/100000)))]
        free = free[::max(1, int(np.ceil(len(free)/100000)))]
        payload = json.dumps(dict(occupied=occupied.tolist(), free=free.tolist(),
                                  path=self.path.copy(), resolution=self.resolution), allow_nan=False)
        html = '''<!doctype html><meta charset="utf-8"><title>FAST-LIO occupancy</title>
<style>body{font:16px sans-serif;margin:20px}canvas{width:95vw;height:75vh;background:#f1f3f5}</style>
<h2>FAST-LIO 三维占据地图 · 高度切片</h2><p id="status"></p>
<p>红：占据；绿：已观测自由；灰：未显示体素（含未知，预览可能抽稀）。蓝：轨迹投影。
初始对齐至 PX4 NED，随后使用 LIO 位姿。
尚未接管飞行导航。<a href="map.html">全部高度点云</a></p>
<label>切片 NED z <input id="height" type="range" step="0.15"><output id="value"></output></label>
<button onclick="location.reload()">刷新</button><canvas id="map" width="1400" height="850"></canvas>
<script>const data=PAYLOAD;
const slider=document.getElementById('height'), canvas=document.getElementById('map'),ctx=canvas.getContext('2d');
const all=data.occupied.concat(data.free); let lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];
for(const p of all)for(let i=0;i<3;i++){lo[i]=Math.min(lo[i],p[i]);hi[i]=Math.max(hi[i],p[i]);}
if(!all.length){lo=[-1,-1,-1];hi=[1,1,1];}
slider.min=lo[2];slider.max=hi[2];slider.value=data.path.at(-1)[2];
function draw(){let z=Number(slider.value);document.getElementById('value').textContent=z.toFixed(2)+' m';
ctx.clearRect(0,0,canvas.width,canvas.height);
let scale=Math.min((canvas.width-40)/Math.max(hi[0]-lo[0],1),(canvas.height-40)/Math.max(hi[1]-lo[1],1));
function point(p,color,size){ctx.fillStyle=color;ctx.fillRect(20+(p[0]-lo[0])*scale,20+(p[1]-lo[1])*scale,size,size);}
for(const [points,color] of [[data.free,'#a2d9ac'],[data.occupied,'#d44949']])
for(const p of points)if(Math.abs(p[2]-z)<=data.resolution/2+1e-6)point(p,color,Math.max(1,data.resolution*scale));
for(const p of data.path)point(p,'#1677ff',2);point(data.path.at(-1),'#111',7);}
slider.oninput=draw;draw();
async function status(){try{const s=await(await fetch('map_status.json',{cache:'no-store'})).json();
document.getElementById('status').textContent=s.status+(s.error?' · '+s.error:'')+' · '+s.scan_model;
document.getElementById('status').style.color=s.status==='failed'?'#b00020':'#333';}catch(e){
document.getElementById('status').textContent='无法读取实时状态；若通过文件打开，请检查同目录 map_status.json';}}
status();setInterval(status,3000);</script>'''.replace('PAYLOAD', payload)
        temporary = self.directory / 'occupancy.html.tmp'
        temporary.write_text(html, encoding='utf-8')
        temporary.replace(self.directory / 'occupancy.html')

    def close(self):
        with self._condition:
            self._closed = True
            self._condition.notify_all()
        if self._thread is not None:
            self._thread.join(timeout=30.)
            if self._thread.is_alive():
                raise TimeoutError('FAST-LIO occupancy worker did not stop')
        self.raise_if_failed()
        self.semantics.drain(final=True)
        self.publish()
        if self.alignment is None:
            return
        np.savez_compressed(self.directory / 'live_map.npz',
                            voxel_indices=np.asarray(sorted(self.cells)), resolution=self.resolution,
                            trajectory=np.asarray(self.path), alignment=self.alignment)
        snapshot = self.occupancy.snapshot()
        np.savez_compressed(self.directory / 'occupancy_map.npz',
                            indices=snapshot.indices, log_odds=snapshot.log_odds,
                            resolution=snapshot.resolution,
                            occupied_threshold=snapshot.occupied_threshold,
                            free_threshold=snapshot.free_threshold,
                            trajectory=np.asarray(self.path), alignment=self.alignment,
                            frame='lio_aligned_to_initial_px4_ned', timestamp=snapshot.timestamp)
        self.occupancy.export_occupied_ply(self.directory / 'occupied.ply')
        occupancy_path = self.occupancy.save(self.directory / 'occupancy_map.h5')
        import h5py
        with h5py.File(occupancy_path, 'r+') as output:
            output.attrs['world_frame'] = 'lio_aligned_to_initial_px4_ned'
            output.attrs['pose_source'] = 'FAST-LIO'
            output.attrs['scan_model'] = self.scan_model
            output.attrs['controls_navigation'] = False
            output.create_dataset('initial_lio_to_ned', data=self.alignment)
            output.create_dataset('trajectory_ned', data=np.asarray(self.path))
        (self.directory / 'live_map.json').write_text(json.dumps(dict(
            frame='lio_aligned_to_initial_px4_ned', scan_model=self.scan_model,
            controls_navigation=False, representation='point_hits_and_raycast_occupancy',
            point_map_representation='point_hits_not_free_space',
            tracking_frames=len(self.path), last_timestamp=self.timestamp,
            occupancy=dict(representation='raycast_log_odds', resolution=self.resolution,
                           voxel_count=snapshot.voxel_count, occupied_count=snapshot.occupied_count,
                           free_count=len(snapshot.free_points_ned),
                           dropped_new_voxels=snapshot.dropped_new_voxels,
                           **self.counts),
            scan_timing_verified=self.scan_model == 'snapshot',
            loop_closure_applied=False), indent=2), encoding='utf-8')
