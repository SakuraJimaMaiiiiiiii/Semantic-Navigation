"""Rebuild occupancy from recorded LIO poses and matching real LiDAR scans.

No flight interfaces are instantiated and no estimator is rerun. Missing LIO
tracking intervals remain unmapped rather than being filled with PX4 poses.
"""
import argparse
import json
from pathlib import Path
import sys

import h5py
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from localization.fastlio_live_map import FastLioLiveMap


def build(source, output):
    source, output = Path(source), Path(output)
    if (source / 'fastlio').is_dir():
        source = source / 'fastlio'
    # Never overwrite a live run or a prior reconstruction.
    output.mkdir(parents=True, exist_ok=False)
    records = {}
    with (source / 'shadow_poses.jsonl').open(encoding='utf-8') as stream:
        for line in stream:
            row = json.loads(line)
            if row['status'] == 'tracking':
                stamp = float(row['timestamp'])
                if stamp in records:
                    raise ValueError('Duplicate recorded LIO timestamp')
                records[stamp] = row
    if not records:
        raise ValueError('No recorded tracking poses; occupancy cannot be reconstructed')
    capture_report = source / 'capture_report.json'
    capture_status = json.loads(capture_report.read_text(encoding='utf-8')) if capture_report.exists() else {}
    with h5py.File(source / 'inputs.h5', 'r') as capture:
        scan_model = str(capture.attrs['scan_model'])
        mapping = FastLioLiveMap(output, scan_model)
        scan_count = len(capture['scans'])
        imu = capture['imu'][:, 0]
        gaps = np.diff(imu)
        mapped = 0
        try:
            for key in sorted(capture['scans']):
                scan = capture['scans'][key]
                stamp = float(scan.attrs['source_timestamp'])
                if stamp not in records:
                    continue
                row = records[stamp]
                body = scan['points_body'][:]
                pose = np.asarray(row['pose'])
                # Native tracking JSON omits point arrays to limit log size.
                result = dict(row, points_world=body @ pose[:3, :3].T + pose[:3, 3])
                mapping.update(result, scan['px4_pose'][:],
                               float(scan.attrs['shared_timestamp']), points_body=body)
                mapping.wait_idle()
                mapped += 1
                if mapped % 50 == 0:
                    print(f'FAST-LIO occupancy: {mapped}/{len(records)} tracking scans', flush=True)
        finally:
            error = capture_status.get('shadow_error') or capture_status.get('error')
            if error:
                mapping.set_estimator_error('Recorded source stopped: '+str(error))
            mapping.close()
    report = dict(source=str(source.resolve()), recorded_scans=scan_count,
                  mapped_scans=mapped, unmatched_tracking_poses=len(records)-mapped,
                  scans_without_tracking=scan_count-mapped,
                  scan_model=scan_model, absolute_accuracy_validated=False,
                  imu_gaps_over_100ms=int(np.count_nonzero(gaps > .1)),
                  max_imu_gap_seconds=float(gaps.max()) if len(gaps) else None,
                  capture_error=capture_status.get('error'),
                  estimator_error=capture_status.get('shadow_error'),
                  semantic_measurements_replayed=False,
                  controls_navigation=False)
    (output / 'reconstruction_report.json').write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.source, args.output), indent=2, ensure_ascii=False))
