# FAST-LIO 三维占据建图（2026-10-29）

`live` 模式现在将实际雷达回波与同帧 FAST-LIO 位姿送入独立的三维概率占据地图。
原有 `map.html` 和 `live_map.npz` 继续保留；原导航仍使用 PX4，尚未把 LIO 地图送入 A*/EGO。
这次完成建图接入，不等同于导航定位接管，也不代表实际精度已经验收。

## 启动与输出

在现有项目 Python 环境运行 `python run_explore.py`，默认配置已为 `fastlio: live`。
当前 `lidar_scan_model: snapshot_assumed` 是瞬时扫描假设，只有获得传感器扫描时序证据后
才改成 `snapshot`，不能通过修改标记证明时序正确。

本次运行目录的 `fastlio/` 新增：

- `occupancy.html`：三维地图的可选高度 XY 切片，红色占据、绿色自由，蓝色为轨迹投影。
  页面只为预览，每类最多约十万个体素；灰色也可能来自预览抽稀，不可当作规划证据。
  点击刷新更新几何；实时状态通过同目录 `map_status.json` 查询，直接用文件协议打开时
  浏览器可能阻止查询，此时直接查看 JSON。
- `occupancy_map.npz`：完整体素索引、log-odds、分辨率、占据/自由阈值、轨迹、初始对齐矩阵。
  未记录的索引为未知；已记录但在两个阈值之间的体素仍是不确定状态。
- `occupancy_map.h5`：复用项目稀疏占据地图格式，坐标轴为初始 PX4 NED 对齐的 LIO 地图轴。
- `occupied.ply`：最终占据体素中心，可由 CloudCompare/Open3D 打开。
- `map_status.json`：tracking/failed/closed、源时间、错误与融合/跳帧计数。
- `live_map.json`：增加占据统计、扫描模型声明、无回环校正声明。

## 融合与线程

首次 tracking 用同期 PX4 位姿作一次刚体对齐。后续雷达位置、朝向和射线起点全部来自
LIO，不逐帧重新对齐 PX4，不用 PX4 填补 LIO 失效段。
当前 Type20 零安装位移、统一机体 FRD，使用实际原始回波，而不是估计器降采样后的
体素质心构造射线。估计器仍使用原有输入、滤波与 tracking 判定。

地图为 0.15m 体素，射线采样间距 0.075m，量程使用 LidarConfig.max_range（30m），
避免沿用深度相机地图的 10m 上限而截断雷达。回波端点增加占据证据，射线内部增加自由证据；
没有回波的方向、端点后方不会被补成自由。未启用机身自由空间填充。
同帧端点不会被该帧自由射线擦除；跨帧证据按现有 log-odds 累积。

占据融合和页面导出在 `FastLioOccupancy` 线程执行，待处理扫描最多一份。
负载过高时只保留最新扫描，丢弃数量记录为 `skipped_mapping_scans`，不能据此声称完整覆盖。
关闭时处理待完成扫描，停止线程后导出完整地图；后台错误显式上报。
语义仍走原有按时间插值的 LIO 独立语义关联链路。

## 离线重建与验证

无需重新飞行或重新运行原生估计器：

```powershell
python tools/build_fastlio_map.py data/runs/run_20261029_101001_223727 --output data/fastlio_validation/自选新目录
```

输出目录必须不存在，原始数据不会被覆盖。工具按录制源时间匹配 tracking 位姿和真实扫描，
逐帧等待融合，不跳帧，不用 PX4 代替缺失的 LIO；本工具不重放语义测量。
`reconstruction_report.json` 保存未匹配扫描数、IMU 空档、原估计器错误。

本次原始运行共有 706 帧雷达。原估计器约运行 23 秒后停止，错误为
`IMU gap exceeds 100 ms`；HIGHRES_IMU 源时间中确有 0.172 秒空档。
因此只能从已有 tracking 记录重建前缀，不能恢复完整探索地图。
在线现已即时提示此类错误，状态文件保留 failed，不再只有结束时的 capture_report 提示。
没有放宽时间阈值、插值补造 IMU 或伪装 tracking。

精度验收还需实际数据：检查输入时序/外参、墙面重影和厚度、UE 真值轨迹、真实闭环误差。
单独比较 PX4 或平面残差不能证明绝对精度；本次没有新增 FAST-LIO 回环后端。

## 本轮验证结果

Windows 项目环境 `Segm-Navi-python3.10`：
`python -X utf8 -m unittest discover -s tests -p "test_fastlio_*.py"`，27 项通过。
新增验证实际回波而非质心参与融合、自由射线与端点后方未知状态、初始对齐后不追随 PX4、
慢融合时有界跳帧、后台错误传播、线程关闭和离线缺失位姿不补填。

已有录制重建位于 `data/fastlio_validation/occupancy_20261029_101001/`。
117 个有效 tracking 扫描全部融合，无跳帧；370542 个体素，22737 个占据、345329 个自由，
其余为阈值之间的不确定体素，没有超过容量而丢失新体素。
另外 589 帧没有 tracking 位姿，未重建。原始 run 文件未改动。
这验证建图接线和保存流程，不代表 UE 真值精度或在线飞行验证。
