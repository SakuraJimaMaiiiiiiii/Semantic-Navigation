import json
from pathlib import Path
import tempfile
import unittest

import h5py
import numpy as np

from tools.build_fastlio_map import build


class MapReconstructionTests(unittest.TestCase):
    def test_only_matching_tracking_scans_are_mapped_and_source_failure_retained(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp)/'source'
            source.mkdir()
            with h5py.File(source/'inputs.h5', 'w') as f:
                f.attrs['scan_model'] = 'snapshot_assumed'
                f.create_dataset('imu', data=np.array([[1., 0.], [1.2, 0.]]))
                scans = f.create_group('scans')
                for i, stamp in enumerate((1., 2.)):
                    scan = scans.create_group(f'{i:08d}')
                    scan.attrs['source_timestamp'] = stamp
                    scan.attrs['shared_timestamp'] = stamp+100.
                    scan.create_dataset('points_body', data=[[1.55, 0., 0.]])
                    scan.create_dataset('px4_pose', data=[0., 0., 0., 1., 0., 0., 0.])
            row = dict(status='tracking', timestamp=1., pose=np.eye(4).tolist())
            (source/'shadow_poses.jsonl').write_text(json.dumps(row)+'\n')
            (source/'capture_report.json').write_text(json.dumps(dict(shadow_error='IMU gap exceeds 100 ms')))
            output = Path(tmp)/'rebuilt'
            report = build(source, output)
            self.assertEqual(report['mapped_scans'], 1)
            self.assertEqual(report['scans_without_tracking'], 1)
            self.assertEqual(report['imu_gaps_over_100ms'], 1)
            self.assertFalse(report['absolute_accuracy_validated'])
            status = json.loads((output/'map_status.json').read_text())
            self.assertEqual(status['status'], 'failed')
            with self.assertRaises(FileExistsError):
                build(source, output)
            with h5py.File(source/'inputs.h5') as f:
                self.assertEqual(len(f['scans']), 2)
