import unittest
import numpy as np
from scipy.spatial.transform import Rotation
from localization.fastlio_navigation_frames import FastLioNavigationFrames


def pose(xyz, yaw=0.):
    result = np.eye(4)
    result[:3, :3] = Rotation.from_euler('z', yaw).as_matrix()
    result[:3, 3] = xyz
    return result


class FastLioNavigationFramesTests(unittest.TestCase):
    def test_map_pose_and_control_goal_use_paired_transform(self):
        clock = [4.]
        bridge = FastLioNavigationFrames(clock=lambda: clock[0], wall_clock=lambda: 100.)
        lio = pose([10., 3., -1.], np.pi / 2)
        px4 = pose([1., 2., -1.])
        bridge.add(100., lio, px4)
        # Goal is 2m ahead in LIO frame; corresponding PX4 goal is +x.
        np.testing.assert_allclose(bridge.px4_goal([10., 5., -1.]), [3., 2., -1.], atol=1e-8)
        target, heading = bridge.px4_position_command([10., 5., -1.], np.pi/2)
        np.testing.assert_allclose(target, [3., 2., -1.], atol=1e-8)
        self.assertAlmostEqual(heading, 0.)
        np.testing.assert_allclose(bridge.px4_velocity([0., 1., 0.]), [1., 0., 0.], atol=1e-8)
        np.testing.assert_allclose(bridge.latest().map_from_body, lio)
        clock[0] += 1.1
        with self.assertRaisesRegex(RuntimeError, 'stale'):
            bridge.px4_goal([10., 5., -1.])

    def test_interpolates_pose_not_paired_correction_and_rejects_gaps(self):
        bridge = FastLioNavigationFrames(max_interpolation_gap=.5)
        bridge.add(10., pose([0., 0., 0.]), pose([1., 0., 0.]))
        bridge.add(10.2, pose([2., 0., 0.], np.pi/2), pose([1., 2., 0.]))
        middle = bridge.at(10.1)
        np.testing.assert_allclose(middle.map_from_body[:3, 3], [1., 0., 0.])
        np.testing.assert_allclose(middle.px4_from_body[:3, 3], [1., 1., 0.])
        np.testing.assert_allclose(middle.map_from_body[:3, :3],
                                   Rotation.from_euler('z', np.pi/4).as_matrix())
        # A camera rigidly attached to the body must have the same map pose
        # whether transformed directly or through the matched PX4 pose.
        sensor = pose([.2, .1, 0.])
        np.testing.assert_allclose(
            bridge.map_observation_pose(10.1, middle.px4_from_body @ sensor),
            middle.map_from_body @ sensor, atol=1e-8)
        bridge.add(11., pose([0, 0, 0]), pose([0, 0, 0]))
        with self.assertRaisesRegex(ValueError, 'gap'):
            bridge.at(10.5)
        with self.assertRaisesRegex(ValueError, 'outside'):
            bridge.at(11.1)

    def test_failed_or_out_of_order_tracking_cannot_issue_goal(self):
        bridge = FastLioNavigationFrames(wall_clock=lambda: 1.)
        bridge.add(1., pose([0, 0, 0]), pose([0, 0, 0]))
        with self.assertRaisesRegex(ValueError, 'increase'):
            bridge.add(1., pose([0, 0, 0]), pose([0, 0, 0]))
        bridge.fail('IMU gap')
        with self.assertRaisesRegex(RuntimeError, 'failed'):
            bridge.px4_goal([1., 0., 0.])

    def test_late_processed_old_scan_is_not_fresh(self):
        bridge = FastLioNavigationFrames(clock=lambda: 10., wall_clock=lambda: 103.)
        bridge.add(100., pose([0, 0, 0]), pose([0, 0, 0]))
        with self.assertRaisesRegex(RuntimeError, 'source timestamp is stale'):
            bridge.px4_goal([1., 0., 0.])
