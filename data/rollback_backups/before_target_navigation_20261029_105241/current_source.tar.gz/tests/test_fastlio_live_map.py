import json
import tempfile
import unittest
import threading
from unittest.mock import patch
from pathlib import Path

import numpy as np

from localization.fastlio_live_map import FastLioLiveMap
from localization.fastlio_recording import FastLioRecorder


class LiveMapTests(unittest.TestCase):
    def test_real_scan_rays_and_lio_pose_own_occupancy(self):
        with tempfile.TemporaryDirectory() as tmp:
            mapping = FastLioLiveMap(tmp, 'snapshot_assumed')
            pose = np.eye(4)
            px4 = np.array([0., 0., 0., 1., 0., 0., 0.])
            # Estimator centroids are deliberately different from actual hits.
            result = dict(status='tracking', timestamp=1., pose=pose,
                          points_world=np.array([[8., 0., 0.]]))
            mapping.update(result, px4, points_body=np.array([[1.55, 0., 0.]]))
            mapping.wait_idle()
            pose[1, 3] = .6
            result['timestamp'] = 2.
            px4[0] = 100.  # LIO, not later PX4, positions the second scan.
            mapping.update(result, px4, points_body=np.array([[1.55, 0., 0.]]))
            mapping.close()
            with np.load(Path(tmp)/'occupancy_map.npz') as data:
                values = {tuple(key): value for key, value in zip(data['indices'], data['log_odds'])}
                self.assertGreaterEqual(values[(10, 0, 0)], data['occupied_threshold'])
                self.assertGreaterEqual(values[(10, 4, 0)], data['occupied_threshold'])
                self.assertLessEqual(values[(3, 0, 0)], data['free_threshold'])
                self.assertNotIn((20, 0, 0), values)  # Beyond hit remains unknown.
                self.assertNotIn((53, 0, 0), values)  # No centroid endpoint.
            self.assertTrue((Path(tmp)/'occupied.ply').exists())
            self.assertTrue((Path(tmp)/'occupancy_map.h5').exists())
            self.assertTrue((Path(tmp)/'occupancy.html').exists())

    def test_mapping_is_bounded_and_does_not_block_estimator(self):
        with tempfile.TemporaryDirectory() as tmp:
            mapping = FastLioLiveMap(tmp, 'snapshot')
            entered, release = threading.Event(), threading.Event()
            original = mapping.occupancy.integrate_lidar_points
            def slow(*args):
                entered.set()
                if not release.wait(5.):
                    raise TimeoutError('Test did not release mapper')
                return original(*args)
            result = dict(status='tracking', timestamp=1., pose=np.eye(4),
                          points_world=np.array([[1., 0., 0.]]))
            px4 = np.array([0., 0., 0., 1., 0., 0., 0.])
            try:
                with patch.object(mapping.occupancy, 'integrate_lidar_points', slow):
                    mapping.update(result, px4)
                    self.assertTrue(entered.wait(2.))
                    for stamp in (2., 3.):
                        mapping.update(dict(result, timestamp=stamp), px4)
                    self.assertEqual(mapping.counts['skipped_mapping_scans'], 1)
                    release.set()
                    mapping.wait_idle()
            finally:
                release.set()
                mapping.close()
            self.assertFalse(mapping._thread.is_alive())
            self.assertEqual(mapping.counts['integrated_scans'], 2)
            self.assertEqual(mapping.occupancy.snapshot().timestamp, 3.)

    def test_worker_failure_is_reported_and_thread_stops(self):
        with tempfile.TemporaryDirectory() as tmp:
            mapping = FastLioLiveMap(tmp, 'snapshot')
            with patch.object(mapping.occupancy, 'integrate_lidar_points', side_effect=ValueError('bad scan')):
                mapping.update(dict(status='tracking', timestamp=1., pose=np.eye(4),
                                    points_world=np.ones((1, 3))), [0, 0, 0, 1, 0, 0, 0])
                with self.assertRaisesRegex(RuntimeError, 'occupancy mapping failed'):
                    mapping.wait_idle()
            with self.assertRaisesRegex(RuntimeError, 'occupancy mapping failed'):
                mapping.close()
            self.assertFalse(mapping._thread.is_alive())

    def test_estimator_failure_is_visible_after_close(self):
        with tempfile.TemporaryDirectory() as tmp:
            mapping = FastLioLiveMap(tmp, 'snapshot_assumed')
            mapping.update(dict(status='tracking', timestamp=1., pose=np.eye(4),
                                points_world=np.ones((1, 3))), [0, 0, 0, 1, 0, 0, 0])
            mapping.set_estimator_error('IMU gap exceeds 100 ms')
            mapping.close()
            status = json.loads((Path(tmp)/'map_status.json').read_text())
            self.assertEqual(status['status'], 'failed')
            self.assertIn('IMU gap', status['error'])

    def test_tracking_publishes_paired_frames_and_failure_invalidates_them(self):
        with tempfile.TemporaryDirectory() as tmp:
            mapping = FastLioLiveMap(tmp, 'snapshot')
            result = dict(status='tracking', timestamp=1., pose=np.eye(4),
                          points_world=np.array([[1., 0., 0.]]))
            import time
            mapping.update(result, [3., 4., -1., 1., 0., 0., 0.], time.time())
            np.testing.assert_allclose(mapping.navigation_frames.latest().map_from_body[:3, 3],
                                       [3., 4., -1.])
            mapping.set_estimator_error('IMU gap')
            with self.assertRaisesRegex(RuntimeError, 'failed'):
                mapping.navigation_frames.latest()
            mapping.close()

    def test_alignment_applied_once_and_exports(self):
        with tempfile.TemporaryDirectory() as tmp:
            mapping = FastLioLiveMap(tmp, 'snapshot_assumed')
            q = np.sqrt(.5)
            px4 = np.array([10., 20., -1., q, 0., 0., q])
            result = dict(status='tracking', timestamp=1., pose=np.eye(4),
                          points_world=np.array([[1., 0., 0.]]))
            self.assertTrue(mapping.update(result, px4))
            np.testing.assert_allclose(mapping.path[0], px4[:3])
            result['pose'][0, 3] = 1.
            result['timestamp'] = 2.
            px4[0] = 999.  # Never re-anchor to later PX4 drift.
            mapping.update(result, px4)
            np.testing.assert_allclose(mapping.path[-1], [10., 21., -1.])
            mapping.close()
            with np.load(Path(tmp)/'live_map.npz') as data:
                self.assertEqual(data['trajectory'].shape, (2, 3))
            metadata = json.loads((Path(tmp)/'live_map.json').read_text())
            self.assertFalse(metadata['controls_navigation'])
            self.assertEqual(metadata['scan_model'], 'snapshot_assumed')
            self.assertTrue((Path(tmp)/'map.html').exists())

    def test_uninitialized_output_not_mapped(self):
        with tempfile.TemporaryDirectory() as tmp:
            mapping = FastLioLiveMap(tmp, 'snapshot')
            self.assertFalse(mapping.update({'status': 'initializing'}, None))
            mapping.close()
            self.assertFalse((Path(tmp)/'live_map.npz').exists())

    def test_initialization_failure_exposed(self):
        recorder = FastLioRecorder('unused', live_map=True, scan_model='snapshot_assumed')
        recorder.estimator_error = 'Bad IMU'
        with self.assertRaisesRegex(RuntimeError, 'Bad IMU'):
            recorder.wait_ready(.5)

    def test_cli_live_assumption_is_explicit(self):
        from run_explore import parse_config
        _, args = parse_config(['--fastlio', 'live', '--lidar-scan-model',
                                'snapshot_assumed'], include_perception=True)
        self.assertEqual(args.fastlio, 'live')
        with self.assertRaises(SystemExit):
            parse_config(['--fastlio', 'live', '--lidar-scan-model', 'unverified'], include_perception=True)
