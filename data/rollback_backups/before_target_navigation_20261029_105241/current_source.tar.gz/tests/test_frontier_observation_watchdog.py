from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
import numpy as np

from navigation.frontier_explorer import FrontierExplorer
from navigation.mission import SemanticNavigator


class ObservationWatchdogTests(unittest.TestCase):
    def test_grid_boundary_recovery_can_use_nearby_certified_center(self):
        from config.semantic_navigation_config import SemanticNavigationConfig
        from navigation.route import NavigationGrid
        nav = object.__new__(FrontierExplorer)
        nav.config = SemanticNavigationConfig(clearance_radius=.4)
        nav.exploration_config = SimpleNamespace(max_radius=100.)
        nav.altitude = -1.49
        nav.exploration_origin = np.zeros(3)
        nav.vehicle = Mock()
        nav.vehicle.get_position.return_value = np.array([6.93, 28.8, -1.49])
        snapshot = SimpleNamespace(resolution=.2, origin_ned=np.array([6., 28., -2.5]),
                                   states=np.zeros((10, 10, 10), dtype=np.int8))
        # Only this coarse center is a global recovery destination. The local
        # map still has to certify the complete path and body footprint.
        world = NavigationGrid(set(), set(), .3, (0., 0.), nav.altitude, nav.config)
        world.free = {(22, 96)}
        path = nav._local_recovery_path(world, snapshot)
        self.assertIsNotNone(path)
        np.testing.assert_allclose(path[-1], world.point((22,96)))
        self.assertLess(np.linalg.norm(path[-1][:2]-path[0][:2]), .8)
        snapshot.states[:] = 1
        self.assertIsNone(nav._local_recovery_path(world, snapshot))

    def test_slow_semantics_do_not_stop_lidar_guarded_transit(self):
        nav = self.explorer(moving=True)
        nav._motion_progress = (np.zeros(3), 20.)
        nav.config.perception_timeout = 5.
        nav.exploration_config.perception_recovery_timeout = 20.
        frame = SimpleNamespace(timestamp=10., completed_at=13., inference_seconds=7.)
        nav.perception = Mock()
        nav.perception.semantic_snapshot.return_value = frame
        nav._latencies = {}
        nav.memory = Mock()
        nav.current_place = 'place_0000'
        nav.object_inspections = Mock()
        nav._inspection_records = Mock(return_value={})
        nav._recover_perception = Mock(return_value=frame)
        nav._check_maps = Mock()
        nav._check_health()
        nav._recover_perception.assert_not_called()
        nav._check_maps.assert_called_once()
        # Geometry freshness remains mandatory even with slower recognition.
        nav._check_maps.side_effect = RuntimeError('semantic_local_map_stale')
        with self.assertRaisesRegex(RuntimeError, 'semantic_local_map_stale'):
            nav._check_health()
        # A stationary decision retains the original semantic timeout.
        nav._motion_progress = None
        nav._frame()
        nav._recover_perception.assert_called_once()
        nav._recover_perception.reset_mock()
        nav._motion_progress = (np.zeros(3), 20.)
        frame.completed_at = -1.
        nav._frame()
        nav._recover_perception.assert_called_once()

    def explorer(self, moving=False):
        nav = object.__new__(FrontierExplorer)
        nav._motion_progress = (np.zeros(3), 0.) if moving else None
        nav.clock = Mock(return_value=20.)
        nav.deadline = 100.
        nav.config = SimpleNamespace(map_timeout=5.)
        nav.exploration_config = SimpleNamespace(
            information_radius=3., camera_fov_degrees=90.,
            recovery_observation_wait=.3, progress_distance=.15, progress_timeout=8.)
        nav.vehicle = Mock()
        nav.vehicle.get_position.return_value = np.zeros(3)
        nav.vehicle.get_euler.return_value = np.zeros(3)
        nav._event = Mock()
        return nav

    def recover_map(self, nav):
        with patch.object(SemanticNavigator, '_check_maps',
                          side_effect=[RuntimeError('semantic_local_map_stale'), None]):
            nav._check_maps()

    def test_map_recovery_does_not_arm_stationary_watchdog(self):
        nav = self.explorer()
        self.recover_map(nav)
        self.assertIsNone(nav._motion_progress)
        with patch.object(SemanticNavigator, '_check_health'):
            nav._check_health()

    def test_map_recovery_resets_active_watchdog(self):
        nav = self.explorer(moving=True)
        self.recover_map(nav)
        self.assertEqual(nav._motion_progress[1], 20.)

    def test_stationary_observation_survives_map_recovery_and_restores_on_error(self):
        for moving in (False, True):
            for fail in (False, True):
                with self.subTest(moving=moving, fail=fail):
                    nav = self.explorer(moving)
                    nav.recovery_yaws = {}
                    grid = Mock(free={(0,0)})
                    grid.cell.return_value = (0,0)
                    def align(yaw):
                        self.assertIsNone(nav._motion_progress)
                        self.recover_map(nav)
                        self.assertIsNone(nav._motion_progress)
                        if fail:
                            raise TimeoutError('yaw_timeout')
                    nav._align = align
                    for name in ('_wait', '_frame', '_record_coverage', '_checkpoint'):
                        setattr(nav, name, Mock())
                    nav._grid = Mock(return_value=grid)
                    with patch('navigation.frontier_explorer.visible_unknown', return_value={(1,1)}):
                        if fail:
                            with self.assertRaisesRegex(TimeoutError, 'yaw_timeout'):
                                nav._recovery_observation(grid,(0,0))
                        else:
                            self.assertTrue(nav._recovery_observation(grid,(0,0)))
                    if moving:
                        self.assertEqual(nav._motion_progress[1],20.)
                    else:
                        self.assertIsNone(nav._motion_progress)

    def test_actual_translation_stall_is_still_detected(self):
        nav = self.explorer(moving=True)
        with patch.object(SemanticNavigator, '_check_health'):
            with self.assertRaisesRegex(TimeoutError,'exploration_no_motion_progress'):
                nav._check_health()
        nav.vehicle.hover.assert_called_once()
